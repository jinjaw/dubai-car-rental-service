# Dubai Car Rental Service Company

This is the official repository for the Dubai Car Rental Service Company website.

## Features

### User Features
- User authentication (sign-up, login, logout)
- Profile management
- Search and filter cars
- Book cars
- View booking history
- Customer support

### Admin Features
- Manage car listings (add, edit, delete)
- View and manage bookings
- Manage users
- Generate reports

## Technology Stack
### Frontend
- HTML, CSS, JavaScript
- React.js

### Backend
- Node.js with Express.js
- MongoDB

### Other Tools
- GitHub for version control
- Heroku or AWS for deployment

## Getting Started
### Prerequisites
- Node.js
- MongoDB
- Git

### Installation
1. Clone the repository:
   ```
   git clone https://github.com/jinjaw/dubai-car-rental-service.git
   ```
2. Install dependencies for frontend and backend:
   ```
   cd frontend
   npm install
   cd ../backend
   npm install
   ```

### Running the Application
1. Start the backend server:
   ```
   cd backend
   npm start
   ```
2. Start the frontend server:
   ```
   cd frontend
   npm start
   ```

## Contributing
We welcome contributions from the community. Please fork the repository and create a pull request with your changes.

## License
This project is licensed under the MIT License.