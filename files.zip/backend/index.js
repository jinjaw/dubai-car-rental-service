const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/dubai-car-rental', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.get('/', (req, res) => {
  res.send('Welcome to Dubai Car Rental Service Company API');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});